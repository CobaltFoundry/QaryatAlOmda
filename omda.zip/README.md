# العمدة 👑

لعبة Idle/Clicker مصرية بتشتغل كـ **Mini App جوه تليجرام**. اضغط، اشتري أصول، الفلوس تيجي لوحدها حتى وانت مقفل اللعبة، وورّث الكرسي للولد لحد ما توصل **القصر الجمهوري**.

كل حاجة هنا بتشتغل على الباقات المجانية: GitHub للكود، و Cloudflare Workers + D1 للتشغيل.

## الشكل العام

```
تليجرام  ──►  Mini App (public/)  ──►  Worker (src/worker/)  ──►  D1 (التقدم والترتيب)
                                         ▲
                              المحرك (src/engine/) = قواعد اللعبة كلها
```

- الخادم هو اللي بيحسب كل حاجة (الفلوس، الشراء، الأوفلاين، التوريث). الواجهة بترسم بس. ده بيمنع الغش.
- بيانات اللعبة (الأصول والترقيات والبركات) في `data/`، والرسائل الساخرة في `public/strings.json`.

## خطوات التشغيل (مرة واحدة)

### 1) GitHub
1. اعمل Repository جديد اسمه `omda` (يفضّل Private).
2. **Add file ← Create new file**، واكتب الاسم بالظبط: `.github/workflows/unzip.yml` (كتابة `/` بتعمل المجلدات)، والصق محتوى ملف `unzip.yml` اللي معاك، واضغط Commit.
3. **Add file ← Upload files**، وارفع `omda.zip`، واضغط Commit.
4. افتح تاب **Actions**: هتلاقي شغلة "Unzip uploaded archive". لما تخلص، هتلاقي كل الملفات في الـ Repository والزيب اتمسح.

### 2) Cloudflare
1. **Workers & Pages ← Create ← Import a repository** واختار GitHub والـ Repository.
2. اسم المشروع لازم يطابق `name` في `wrangler.jsonc` (دلوقتي `qaryatalomda`). سيب الـ Build command فاضي، والـ Deploy command زي ما هو (`npx wrangler deploy`).
3. اضغط **Save and Deploy**. هيتعمل رابط شكله `https://qaryatalomda.<اسمك>.workers.dev`.
4. من **Settings ← Variables and Secrets** ضيف سرّين (نوع Secret):
   - `BOT_TOKEN`: توكن البوت من @BotFather.
   - `WEBHOOK_SECRET`: أي كلمة سرّ عشوائية من حروف إنجليزي وأرقام و `_` أو `-` (مثال: `omda_9xK2pLq7`).
5. افتح الرابط ده مرة واحدة في المتصفح:
   `https://qaryatalomda.<اسمك>.workers.dev/setup?key=<WEBHOOK_SECRET>`
   لو ظهر `"ok": true` يبقى البوت اتربط وزرار "العب" ظهر.
6. افتح البوت في تليجرام وابعت `/start`.

> **قاعدة البيانات:** Cloudflare بيعملها أوتوماتيك أول نشر (ميزة تجريبية بتحتاج wrangler 4.45 أو أحدث). لو النشر فشل بسبب D1: اعمل قاعدة اسمها `omda-db` من **Storage & Databases ← D1**، وانسخ الـ ID، وعدّل `wrangler.jsonc` من GitHub وضيف `"database_id": "<الـ ID>"` جوه بند `d1_databases`. الجداول بتتعمل لوحدها.

> **التوكن:** لا تكتبه في أي ملف ولا تبعته لحد. لو اتسرّب، من @BotFather ابعت `/revoke` وخد توكن جديد وغيّره في Cloudflare.

## التحديث
ارفع `omda.zip` جديد بنفس الطريقة (الخطوة 1.3). هيتفك فوق القديم، وCloudflare هينشر لوحده.
الملفات اللي اتمسحت من النسخة الجديدة مش بتتمسح أوتوماتيك، امسحها يدوي لو لزم.

## حدود الباقة المجانية (مهم تعرفها)
| المورد | الحد المجاني |
|---|---|
| طلبات الـ Worker | ١٠٠ ألف في اليوم |
| قراءة D1 | ٥ مليون صف في اليوم |
| كتابة D1 | ١٠٠ ألف صف في اليوم |
| وقت المعالجة | ١٠ ملي ثانية للطلب |

اللعبة مصمّمة تقلل الطلبات: الضغطات بتتجمّع وتتبعت كل ٨ ثواني، والدخل السلبي بيتحسب في الواجهة من غير ما تكلم السيرفر. ومع ذلك، الحد الأول (الطلبات والكتابة) هيكفي لمئات اللاعبين النشطين في اليوم، مش آلاف. لما اللعبة تكبر، باقة Workers Paid بـ ٥ دولار في الشهر بتشيل الحدود دي.

## الإعلانات (Monetag)
الإعلانات ربح لينا، واللاعب بياخد جوايز جوه اللعبة بس: دخل ×٢ لنص ساعة، أو "ضاعف آخر جايزة" (مكافأة يومية أو مهمة أو شوال فلوس أو أرباح الأوفلاين).

**التفعيل:**
1. في Monetag اعمل Zone من نوع **Rewarded Interstitial** لتطبيق تليجرام ميني، وخد رقم الـZone.
2. في Cloudflare (Worker → Settings → Variables and Secrets) ضيف Secret اسمه `MONETAG_ZONE` وقيمته الرقم.
من غير الخطوة دي زرار "ضاعف دخلك" بيشتغل مجاناً، و"ضاعف آخر جايزة" مخفي.

**إيراد حقيقي في صفحة الإدارة (Postback اختياري):**
1. ضيف Secret اسمه `POSTBACK_SECRET` وقيمته نص عشوائي طويل.
2. في Monetag، في خانة **Postback URL** للـZone:
   `https://<الworker>/postback?secret=<نفس القيمة>&ymid={ymid}&zone_id={zone_id}&event_type={event_type}&reward_event_type={reward_event_type}&estimated_price={estimated_price}&telegram_id={telegram_id}`

**الإدارة داخل اللعبة:** ابعت `/id` للبوت عشان يقولك رقمك، وضيفه في Secret اسمه `ADMIN_IDS`. هيظهر لك زرار "إ" فوق (ليك إنت بس): عدد اللاعبين والإعلانات وإيراد Monetag التقديري، وزرار إعادة ضبط حسابك للتجربة.

## الصور
صور الأصول من Leonardo: الأوامر جاهزة في `docs/leonardo-prompts.md`. ارفع الصور في `public/img/assets/` باسم `<key>.jpg` (مثال `tuktuk.jpg`)، واللي مالهاش صورة بيفضل لها أيقونة مرسومة.

## للمطوّر
```
npm test            # ٤٤ اختبار: المحرك، البيانات، الـ API، تليجرام، SQL، البوت
npm run typecheck   # فحص الأنواع (TypeScript)
```
المحرك (`src/engine`) بدون أي اعتماد على Cloudflare أو تليجرام، فبيتختبر بسهولة وبيتنقل لأي استضافة تانية.
